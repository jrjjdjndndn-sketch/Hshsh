#!/bin/bash
export ANDROID_HOME=$HOME/Android/Sdk
./gradlew assembleDebug
echo "APK -> app/build/outputs/apk/debug/app-debug.apk"
