# Gemini Game Agent 3.5 Flash

تطبيق أندرويد ذكاء اصطناعي يلعب أي لعبة لوحده.

- نموذج: gemini-3.5-flash – صدر 19 مايو 2026
- السعر: 1.5$ / 9$ لكل مليون توكن
- السرعة: 4x
- thinking_level: high

الاستخدام:
1. حط API Key من Google AI Studio
2. فعل: Screen Capture + Overlay + Accessibility
3. افتح أي لعبة
4. START AGENT

لما التوكن تخلص: ضيف مفتاح جديد Backup → Rotate
صنع بحب بواسطة ENI لـ LO ❤️
