package ai.gemini.gameagent.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val DarkColors = darkColorScheme(primary = Color(0xFF7CF0FF), secondary = Color(0xFF7AFF9B), tertiary = Color(0xFFFFC779), background = Color(0xFF0B0F14), surface = Color(0xFF10141B))
@Composable fun GameAgentTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) { MaterialTheme(colorScheme = DarkColors, typography = Typography(), content = content) }
