package ai.gemini.gameagent.service
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
class GameAgentAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: GameAgentAccessibilityService? = null; private set }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { super.onDestroy(); instance = null }
    suspend fun tap(x:Int,y:Int,duration:Long=80): Boolean = suspendCoroutine { cont ->
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,duration)).build()
        dispatchGesture(gesture, object: GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { cont.resume(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { cont.resume(false) }
        }, null)
    }
    suspend fun swipe(x1:Int,y1:Int,x2:Int,y2:Int,duration:Long=250): Boolean = suspendCoroutine { cont ->
        val path = Path().apply { moveTo(x1.toFloat(),y1.toFloat()); lineTo(x2.toFloat(),y2.toFloat()) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,duration)).build()
        dispatchGesture(gesture, object: GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { cont.resume(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { cont.resume(false) }
        }, null)
    }
}
