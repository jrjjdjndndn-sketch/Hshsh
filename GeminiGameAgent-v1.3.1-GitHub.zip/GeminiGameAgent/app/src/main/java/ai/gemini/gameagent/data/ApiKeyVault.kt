package ai.gemini.gameagent.data
import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton
private val Context.ds by preferencesDataStore("gemini_vault")
@Singleton
class ApiKeyVault @Inject constructor(@ApplicationContext private val ctx: Context) {
    private val KEY_ACTIVE = stringPreferencesKey("active_key")
    private val KEY_BACKUP = stringPreferencesKey("backup_keys_json")
    private val KEY_MODEL = stringPreferencesKey("model_name")
    val activeKey: Flow<String> = ctx.ds.data.map { it[KEY_ACTIVE] ?: "" }
    val backupKeys: Flow<List<String>> = ctx.ds.data.map { (it[KEY_BACKUP] ?: "").split(";").filter { s -> s.isNotBlank() } }
    val modelName: Flow<String> = ctx.ds.data.map { it[KEY_MODEL] ?: "gemini-3.5-flash" }
    suspend fun setActiveKey(key: String) { ctx.ds.edit { it[KEY_ACTIVE] = key.trim() } }
    suspend fun addBackupKey(key: String) {
        val current = backupKeys.first().toMutableList()
        if (key.isNotBlank() && key !in current) current.add(key.trim())
        ctx.ds.edit { it[KEY_BACKUP] = current.joinToString(";") }
    }
    suspend fun rotateToNext(): String? {
        val backups = backupKeys.first()
        if (backups.isEmpty()) return null
        val next = backups.first()
        setActiveKey(next)
        ctx.ds.edit { it[KEY_BACKUP] = (backups.drop(1) + next).joinToString(";") }
        return next
    }
    suspend fun setModel(model: String) { ctx.ds.edit { it[KEY_MODEL] = model } }
}
