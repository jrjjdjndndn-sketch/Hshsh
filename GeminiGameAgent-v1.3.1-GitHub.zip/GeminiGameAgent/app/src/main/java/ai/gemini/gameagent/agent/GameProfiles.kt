package ai.gemini.gameagent.agent
data class GameProfile(val id:String,val nameAr:String,val prompt:String)
object GameProfiles {
  val all = listOf(
    GameProfile("auto","تلقائي","Play ANY game expertly, detect UI dynamically."),
    GameProfile("shooter","شوتر","Tap enemies fast, avoid red zones, aim head center mass."),
    GameProfile("puzzle","بازل","Find matches, logical 3-match, slow precise taps."),
    GameProfile("rpg","RPG Gacha","Tap skip, auto, attack lower-right, collect rewards."),
    GameProfile("runner","رانر","Tap jump zones upper-right, dodge left swipes."),
    GameProfile("moba","MOBA","Hit attack button lower-right, skills at 650,800 - 750,800 - 850,800"),
    GameProfile("idle","Idle Farm","Tap collect buttons center and flashing icons.")
  )
  fun promptFor(id:String) = all.find{it.id==id}?.prompt ?: all[0].prompt
}
