package ai.gemini.gameagent.agent
import android.content.Context
import android.graphics.Bitmap
import android.util.DisplayMetrics
import android.view.WindowManager
import ai.gemini.gameagent.data.ApiKeyVault
import ai.gemini.gameagent.service.GameAgentAccessibilityService
import ai.gemini.gameagent.service.ScreenCaptureService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
object AgentOrchestrator {
    @Volatile var isRunning = false; private set
    @Volatile var lastConf = 0f
    @Volatile var lastFps = 0
    private var job: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    fun start(ctx: Context, vault: ApiKeyVault, agent: GeminiFlashAgent, gameHint:String="auto") {
        if (isRunning) return; isRunning = true
        job = scope.launch {
            var frames=0; var lastSec=System.currentTimeMillis(); var lastActionStr="none"
            while(isActive && isRunning) {
                try {
                    val apiKey = vault.activeKey.first()
                    val model = vault.modelName.first()
                    if (apiKey.isBlank()) { delay(1000); continue }
                    val bmp: Bitmap? = ScreenCaptureService.latestFrame
                    if (bmp == null) { delay(250); continue }
                    val decision = try { agent.analyzeGameFrame(apiKey,bmp,gameHint,lastActionStr,model) }
                    catch(e:Exception){
                        if(e.message?.contains("429",true)==true || e.message?.contains("quota",true)==true) vault.rotateToNext()
                        delay(800); continue
                    }
                    lastConf = decision.confidence
                    val svc = GameAgentAccessibilityService.instance
                    if (svc != null) {
                        val dm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                        val metrics = DisplayMetrics(); @Suppress("DEPRECATION") dm.defaultDisplay.getRealMetrics(metrics)
                        val sw = metrics.widthPixels; val sh = metrics.heightPixels
                        for (a in decision.actions.take(3)) {
                            val x = (a.x * sw / 1000).coerceIn(0,sw-1)
                            val y = (a.y * sh / 1000).coerceIn(0,sh-1)
                            when(a.type){"tap","click"->svc.tap(x,y,a.duration_ms.toLong());"longpress"->svc.tap(x,y,650);"swipe"->svc.swipe(x,y,x,(y-sw/3).coerceAtLeast(60),240);"back"->svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)}
                            lastActionStr = "${a.type} $x,$y"
                            delay(45)
                        }
                    }
                    frames++; val now=System.currentTimeMillis()
                    if(now-lastSec>1000){ lastFps=frames; frames=0; lastSec=now }
                    delay(decision.next_wait_ms.toLong().coerceIn(120,1800))
                } catch(_:Exception){ delay(500) }
            }
        }
    }
    fun stop(){ isRunning=false; job?.cancel(); job=null }
}
