package ai.gemini.gameagent.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import ai.gemini.gameagent.agent.AgentOrchestrator
import ai.gemini.gameagent.ui.AgentViewModel
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RootNav(vm: AgentViewModel = hiltViewModel(), onRequestCapture:()->Unit, onRequestOverlay:()->Unit){
    val key by vm.activeKey.collectAsState()
    val backups by vm.backupKeys.collectAsState()
    val model by vm.modelName.collectAsState()
    val status by vm.status.collectAsState()
    val hint by vm.gameHint.collectAsState()
    var keyInput by remember(key){ mutableStateOf(key) }
    var backupInput by remember { mutableStateOf("") }
    var localModel by remember(model){ mutableStateOf(model) }
    var localHint by remember(hint){ mutableStateOf(hint) }
    var running by remember { mutableStateOf(AgentOrchestrator.isRunning) }
    LaunchedEffect(Unit){ while(true){ running = AgentOrchestrator.isRunning; kotlinx.coroutines.delay(400)} }
    Scaffold(topBar = { TopAppBar(title = { Text("Gemini Game Agent 3.5 Flash") }) }){ pad ->
        Column(Modifier.padding(pad).padding(18.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Universal AI Game Player", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text("model: gemini-3.5-flash • I/O May 19 2026 • $1.50/$9 M • 4x speed • thinking_level high", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(value = keyInput, onValueChange = { keyInput = it }, label = { Text("Google AI Studio API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.saveKey(keyInput) }) { Text("Save Key") }
                OutlinedButton(onClick = { vm.rotateKey() }) { Text("Rotate") }
            }
            OutlinedTextField(value = backupInput, onValueChange = { backupInput = it }, label = { Text("Add backup API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { vm.addBackup(backupInput); backupInput = "" }, enabled = backupInput.length>10) { Text("Add to vault") }
            Text("Vault: ${backups.size} backup keys", style = MaterialTheme.typography.bodySmall)
            Divider()
            OutlinedTextField(value = localModel, onValueChange = { localModel = it }, label = { Text("Model name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = { vm.setModel(localModel) }) { Text("Apply Model") }
            Text("gemini-3.5-flash  •  gemini-3.5-pro (June)", style = MaterialTheme.typography.labelSmall)
            OutlinedTextField(value = localHint, onValueChange = { localHint = it; vm.setHint(it) }, label = { Text("Game hint: auto / shooter / puzzle / rpg / runner") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Divider()
            Text(status, style = MaterialTheme.typography.bodyMedium)
            Text("conf: ${"%.2f".format(AgentOrchestrator.lastConf)}  fps:${AgentOrchestrator.lastFps}  running:$running", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { onRequestCapture(); onRequestOverlay() }, modifier = Modifier.weight(1f)) { Text("1. Permissions") }
                Button(onClick = { if(!running) vm.startAgent() else vm.stopAgent() },
                    colors = ButtonDefaults.buttonColors(containerColor = if(running) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary),
                    modifier = Modifier.weight(1f)) { Text(if(running) "STOP AGENT" else "START AGENT") }
            }
            Text("الاستخدام:\n1) حط API key من Google AI Studio\n2) فعل Screen Capture + Overlay + Accessibility (إمكانية الوصول)\n3) افتح أي لعبة\n4) START AGENT – Gemini 3.5 Flash هيلعب لوحده\n• لما التوكن تخلص: ضيف مفتاح جديد Backup واضغط Rotate", style = MaterialTheme.typography.bodySmall)
        }
    }
}
