package ai.gemini.gameagent.ui
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ai.gemini.gameagent.agent.AgentOrchestrator
import ai.gemini.gameagent.agent.GeminiFlashAgent
import ai.gemini.gameagent.data.ApiKeyVault
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
@HiltViewModel
class AgentViewModel @Inject constructor(@ApplicationContext private val ctx: Context, private val vault: ApiKeyVault, private val agent: GeminiFlashAgent): ViewModel() {
    val activeKey = vault.activeKey.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val backupKeys = vault.backupKeys.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val modelName = vault.modelName.stateIn(viewModelScope, SharingStarted.Eagerly, "gemini-3.5-flash")
    private val _status = MutableStateFlow("Idle - Gemini 3.5 Flash ready")
    val status: StateFlow<String> = _status
    private val _gameHint = MutableStateFlow("auto")
    val gameHint: StateFlow<String> = _gameHint
    fun saveKey(key:String) = viewModelScope.launch { vault.setActiveKey(key); _status.value = "API key saved ✓" }
    fun addBackup(key:String) = viewModelScope.launch { vault.addBackupKey(key); _status.value = "Backup key added" }
    fun setModel(m:String) = viewModelScope.launch { vault.setModel(m); _status.value = "Model: $m" }
    fun setHint(h:String){ _gameHint.value = h }
    fun startAgent(){ AgentOrchestrator.start(ctx, vault, agent, _gameHint.value); _status.value = "Agent RUNNING - Gemini 3.5 Flash" }
    fun stopAgent(){ AgentOrchestrator.stop(); _status.value = "Stopped" }
    fun rotateKey() = viewModelScope.launch { val n = vault.rotateToNext(); _status.value = if(n!=null) "Rotated → ${n.take(8)}…" else "No backup keys" }
}
