package ai.gemini.gameagent.ui
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import ai.gemini.gameagent.service.ScreenCaptureService
import ai.gemini.gameagent.ui.screens.RootNav
import ai.gemini.gameagent.ui.theme.GameAgentTheme
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) { ScreenCaptureService.projectionData = res.data
            startService(Intent(this, ScreenCaptureService::class.java).apply { putExtra("i", res.data) }) }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GameAgentTheme { Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            RootNav(onRequestCapture = { requestCapture() }, onRequestOverlay = { requestOverlay() }) } } }
    }
    private fun requestCapture(){ val mpm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; captureLauncher.launch(mpm.createScreenCaptureIntent()) }
    private fun requestOverlay(){ if(!Settings.canDrawOverlays(this)){ startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } }
}
