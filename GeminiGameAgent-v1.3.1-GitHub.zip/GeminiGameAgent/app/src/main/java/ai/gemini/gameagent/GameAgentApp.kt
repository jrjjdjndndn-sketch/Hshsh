package ai.gemini.gameagent
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp
class GameAgentApp : Application()
