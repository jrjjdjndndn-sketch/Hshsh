package ai.gemini.gameagent.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ai.gemini.gameagent.agent.GeminiFlashAgent
import ai.gemini.gameagent.data.ApiKeyVault
import kotlinx.coroutines.launch
@Composable
fun DebugChatScreen(vault: ApiKeyVault, agent: GeminiFlashAgent){
  var input by remember{ mutableStateOf("") }
  val msgs = remember{ mutableStateListOf<String>() }
  val scope = rememberCoroutineScope()
  Column(Modifier.fillMaxSize().padding(12.dp)){
    Text("Gemini 3.5 Flash – Debug Chat", style = MaterialTheme.typography.titleMedium)
    LazyColumn(Modifier.weight(1f)){ items(msgs){ Text(it, modifier=Modifier.padding(4.dp)) } }
    Row{ OutlinedTextField(input,{input=it},Modifier.weight(1f), singleLine=true)
      Button(onClick={ scope.launch{
        val key = vault.activeKey; // simplified
        msgs.add("you: $input"); msgs.add("…thinking high…"); input=""
      }}){ Text("Send") } }
  }
}
