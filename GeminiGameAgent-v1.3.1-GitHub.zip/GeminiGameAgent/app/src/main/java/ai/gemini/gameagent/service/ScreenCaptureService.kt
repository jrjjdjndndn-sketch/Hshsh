package ai.gemini.gameagent.service
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
class ScreenCaptureService: Service() {
    companion object { @Volatile var latestFrame: Bitmap? = null; var projectionData: Intent? = null }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags:Int, startId:Int): Int {
        startForeground(77, notif())
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val data = projectionData ?: intent
        if (data != null && projection == null) { try { projection = mpManager.getMediaProjection(Activity.RESULT_OK, data); startCapture() } catch(_:Exception){} }
        return START_STICKY
    }
    private fun startCapture(){
        val dm = resources.displayMetrics; val w=dm.widthPixels; val h=dm.heightPixels
        reader = ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        vDisplay = projection?.createVirtualDisplay("gemini_agent",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface,null,null)
        scope.launch { while(isActive){ try{
            val img = reader?.acquireLatestImage()
            if(img!=null){ val planes=img.planes; val buffer=planes[0].buffer; val pixelStride=planes[0].pixelStride; val rowStride=planes[0].rowStride; val rowPadding=rowStride-pixelStride*w
                val bmp=Bitmap.createBitmap(w+rowPadding/pixelStride,h,Bitmap.Config.ARGB_8888); bmp.copyPixelsFromBuffer(buffer)
                latestFrame?.recycle(); latestFrame=Bitmap.createBitmap(bmp,0,0,w,h); bmp.recycle(); img.close()
            }}catch(_:Exception){}; delay(120) } }
    }
    private fun notif(): Notification {
        val chId="agent_cap"; val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.O){ nm.createNotificationChannel(NotificationChannel(chId,"Game Agent",NotificationManager.IMPORTANCE_LOW)) }
        return NotificationCompat.Builder(this,chId).setContentTitle("Gemini 3.5 Flash Agent").setContentText("Screen analyzing…").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    }
    override fun onDestroy(){ vDisplay?.release(); reader?.close(); projection?.stop(); scope.cancel(); super.onDestroy() }
}
