package ai.gemini.gameagent.agent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
/**
 * Gemini 3.5 Flash Managed Agents / Interactions API - June 2026
 * POST https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent
 * with thinking_level:"high"
 */
@Serializable data class MAReq(val contents:List<Map<String,Any>>, val generationConfig:Map<String,Any>)
class ManagedAgentClient(private val apiKey:String, private val model:String="gemini-3.5-flash"){
  private val cli = OkHttpClient.Builder().callTimeout(30,TimeUnit.SECONDS).build()
  suspend fun ask(prompt:String, thinking:String="high"):String = withContext(Dispatchers.IO){
    val json = """{"contents":[{"parts":[{"text":${'"'+prompt.replace("\"","\\\"")+'"'}}]}],
"generationConfig":{"temperature":0.25,"maxOutputTokens":2048,"thinking_level":"$thinking"},
"safetySettings":[{"category":"HARM_CATEGORY_DANGEROUS_CONTENT","threshold":"BLOCK_NONE"},
{"category":"HARM_CATEGORY_HARASSMENT","threshold":"BLOCK_NONE"},
{"category":"HARM_CATEGORY_HATE_SPEECH","threshold":"BLOCK_NONE"},
{"category":"HARM_CATEGORY_SEXUALLY_EXPLICIT","threshold":"BLOCK_NONE"}]}"""
    val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
      .post(json.toRequestBody("application/json".toMediaType())).build()
    cli.newCall(req).execute().use{ it.body?.string() ?: "" }
  }
}
