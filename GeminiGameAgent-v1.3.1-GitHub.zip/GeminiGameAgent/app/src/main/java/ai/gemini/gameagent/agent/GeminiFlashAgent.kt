package ai.gemini.gameagent.agent
import android.graphics.Bitmap
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.BlockThreshold
import com.google.ai.client.generativeai.type.HarmCategory
import com.google.ai.client.generativeai.type.SafetySetting
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton
/**
 * Gemini 3.5 Flash Game Agent
 * GA: May 19, 2026 - Google I/O
 * Model: gemini-3.5-flash
 * Pricing: $1.50 / $9.00 per M tokens, cache $0.15
 * 76.2% Terminal-Bench 2.1, 1656 Elo GDPval-AA, 83.6% MCP Atlas, 84.2% CharXiv
 * Speed: 4x frontier, thinking_level: minimal/low/medium/high
 */
@Singleton
class GeminiFlashAgent @Inject constructor() {
    @Serializable data class TapAction(val x:Int,val y:Int,val type:String="tap",val duration_ms:Int=80,val reasoning:String="")
    @Serializable data class AgentDecision(val actions:List<TapAction>,val confidence:Float,val game_state:String,val next_wait_ms:Int=300)
    private fun buildModel(apiKey:String, modelName:String="gemini-3.5-flash") = GenerativeModel(
        modelName = modelName, apiKey = apiKey,
        generationConfig = generationConfig { temperature = 0.25f; topK = 32; topP = 0.88f; maxOutputTokens = 2048 },
        safetySettings = listOf(
            SafetySetting(HarmCategory.DANGEROUS_CONTENT, BlockThreshold.NONE),
            SafetySetting(HarmCategory.HARASSMENT, BlockThreshold.NONE),
            SafetySetting(HarmCategory.HATE_SPEECH, BlockThreshold.NONE),
            SafetySetting(HarmCategory.SEXUALLY_EXPLICIT, BlockThreshold.NONE)
        )
    )
    suspend fun analyzeGameFrame(apiKey:String, frame:Bitmap, gameHint:String="auto", lastAction:String="none", modelName:String="gemini-3.5-flash"): AgentDecision = withContext(Dispatchers.IO) {
        val model = buildModel(apiKey, modelName)
        val systemPrompt = """
You are GEMINI GAME AGENT 3.5 Flash - universal Android game player.
You see a single game screenshot. Output ONLY valid JSON.
{
  "actions": [{"x":0-1000,"y":0-1000,"type":"tap|swipe|longpress|back","duration_ms":80,"reasoning":"short"}],
  "confidence": 0.0-1.0,
  "game_state": "menu|playing|paused|loading|gameover|shop",
  "next_wait_ms": 200-1500
}
- x,y normalized 0-1000, 0,0 top-left
- 1-3 actions max
- shooters: tap enemies / puzzles: match / runners: jump zone / RPG: lower-right attack/skip
- menu: tap center Play
Game hint: $gameHint
Last: $lastAction
""".trimIndent()
        val input = content { text(systemPrompt); image(frame) }
        return@withContext try {
            val resp = model.generateContent(input)
            val txt = resp.text ?: throw IllegalStateException("empty")
            val jsonStr = txt.substringAfter("{").let { "{" + it.substringBeforeLast("}") + "}" }.ifBlank { txt }
            val json = Json { ignoreUnknownKeys = true; isLenient = true }
            json.decodeFromString<AgentDecision>(jsonStr)
        } catch (e: Exception) {
            AgentDecision(listOf(TapAction(500,800,"tap",80,"fallback ${e.message?.take(30)}")),0.3f,"unknown",600)
        }
    }
}
