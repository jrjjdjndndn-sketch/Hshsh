package ai.gemini.gameagent.di
import android.content.Context
import ai.gemini.gameagent.agent.GeminiFlashAgent
import ai.gemini.gameagent.data.ApiKeyVault
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton fun appScope(): CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Provides @Singleton fun vault(@ApplicationContext ctx: Context): ApiKeyVault = ApiKeyVault(ctx)
    @Provides @Singleton fun agent(): GeminiFlashAgent = GeminiFlashAgent()
}
