@echo off
echo === Gemini Game Agent 3.5 Flash - BUILD ===
set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk
call gradlew.bat assembleDebug
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
