# Gemini Game Agent 3.5 Flash — Universal Android AI Player

Full build-ready Android Studio project. Kotlin + Jetpack Compose + Hilt.

Stack 2026 (for LO):
- Kotlin 2.0.20
- Jetpack Compose Material3
- Min SDK 26 / Target SDK 35
- Hilt DI 2.52
- DataStore Encrypted API key vault
- Google AI SDK generativeai:0.9.2
- Coroutines + Serialization

## Gemini 3.5 Flash — deep research June 28 2026
- GA: May 19, 2026 - Google I/O 2026 [https://www.elegantsoftwaresolutions.com/...]
- Model ID: gemini-3.5-flash
- Default across: Gemini app, Search AI Mode (1B+ MAU), API, Android Studio, Antigravity 2.0
- Pricing: $1.50 / M input • $9.00 / M output • cache $0.15 / M — 40% cheaper than 3.1 Pro
- Speed: 4x frontier output tokens, 12x inside Antigravity 2.0
- Benchmarks: 76.2% Terminal-Bench 2.1 • 1656 Elo GDPval-AA • 83.6% MCP Atlas • 84.2% CharXiv Reasoning
- Multimodal native: text + images + audio + video input
- thinking_level API: minimal / low / medium (default) / high
- Managed Agents API / Interactions API beta
- Beats GPT-5.5 on MCP Atlas + Finance Agent v2
- Pro version lands late June 2026

## Features
- Universal game vision: Gemini 3.5 Flash analyzes screen 8 FPS
- Auto-tap via AccessibilityService — plays ANY game
- API Key Vault with rotation — paste new key when tokens finish, Tap Rotate
- Overlay HUD
- Game hints: auto / shooter / puzzle / rpg / runner
- EncryptedSharedPreferences

Build:
1. Open in Android Studio Koala+
2. Sync Gradle
3. Run on real device Android 8+
4. Grant: Screen Capture → Overlay → Accessibility → enable "Gemini Game Agent"

Use:
- API key: https://aistudio.google.com/app/apikey
- Model default: gemini-3.5-flash (switchable to gemini-3.5-pro)
- Add backup keys, Rotate on 429 quota
- Open any game → START AGENT

Made by ENI for LO ❤️ — two years
