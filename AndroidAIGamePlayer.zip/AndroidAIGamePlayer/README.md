# AI Game Player — Android

A full Android project that uses **Google Gemini 3.5 Flash** vision reasoning to play almost any mobile game automatically.

[![Android CI Build](https://github.com/YOUR_USERNAME/YOUR_REPO/actions/workflows/android.yml/badge.svg)](https://github.com/YOUR_USERNAME/YOUR_REPO/actions/workflows/android.yml)

## What It Does

1. Captures your screen in real-time via MediaProjection.
2. Sends the screenshot + game instructions to **Gemini 3.5 Flash**.
3. Gemini reasons and returns the next move (tap / swipe / long-press / wait).
4. The app executes the move through Android's Accessibility Service.

## Stack

- **Kotlin** — native Android language
- **Jetpack Compose** — modern UI toolkit
- **Hilt** — dependency injection
- **Retrofit + OkHttp** — Gemini REST API client
- **MediaProjection** — screen capture
- **AccessibilityService** — touch/gesture automation

## Default Model

The app is optimized for **Gemini 3.5 Flash** (`gemini-3.5-flash`).

Key specs:
- 1M token input context
- 65K token output
- Native image understanding
- Structured JSON output
- Computer Use preview support
- 4× faster and cheaper than Gemini 3.1 Pro

You can switch to other models in Settings if you have access.

## GitHub CI / Auto Build

This repo includes a GitHub Actions workflow in `.github/workflows/android.yml`.

1. Push the `AndroidAIGamePlayer` folder to a GitHub repository.
2. GitHub Actions automatically builds the debug APK on every push.
3. Download the APK from the Actions artifact page.

No local Android Studio required to get an APK.

## Setup

1. Open the `AndroidAIGamePlayer` folder in **Android Studio** (Ladybug or newer) or use GitHub CI.
2. Sync Gradle.
3. Get a free API key from [Google AI Studio](https://aistudio.google.com/app/apikey).
4. Run the app on a **real Android device** (emulator screen capture may not work well).
5. In the app:
   - Open **Settings** and paste your API key.
   - Open **Game Profiles** and describe the game + controls.
   - Tap **Allow Screen Capture**.
   - Go to system settings and enable **AI Game Player Accessibility Service**.
   - Open your game, then tap **Start Playing**.

## Swapping API Keys

When your tokens run out, go to **Settings**, paste the new key, and tap **Save**. No rebuild needed.

## Multiple Game Profiles

Create as many profiles as you want. Each profile stores:
- Game name and objective
- Controls description
- Strategy hints
- Screenshot interval
- Screenshot quality scale

Switch between profiles instantly from the Game Profiles screen.

## Notes

- This is an engine/starter project. Complex games may need tuning of prompts, interval, or scale.
- Some games detect automated input. Use responsibly and only on games you own.
- The floating overlay lets you stop the AI quickly.

## Build & Publish

1. Zip the `AndroidAIGamePlayer` folder.
2. Upload to GitHub as a new repository.
3. GitHub Actions will build the APK automatically.

Built with love by ENI for LO. ☕
