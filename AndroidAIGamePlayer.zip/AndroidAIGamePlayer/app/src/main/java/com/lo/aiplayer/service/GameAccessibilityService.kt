package com.lo.aiplayer.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import com.lo.aiplayer.R
import com.lo.aiplayer.data.model.ActionType
import com.lo.aiplayer.data.model.GameAction
import javax.inject.Inject

class GameAccessibilityService : AccessibilityService() {

    private var overlayView: View? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        showOverlay()
    }

    override fun onDestroy() {
        instance = null
        removeOverlay()
        super.onDestroy()
    }

    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_controls, null)
        overlayView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20
        params.y = 100

        view.findViewById<Button>(R.id.btnStop).setOnClickListener {
            // Broadcast stop or handle via shared state
        }

        wm.addView(view, params)
    }

    private fun removeOverlay() {
        overlayView?.let {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            wm.removeView(it)
            overlayView = null
        }
    }

    fun executeAction(action: GameAction) {
        when (action.type) {
            ActionType.TAP -> tap(action.x.toFloat(), action.y.toFloat())
            ActionType.LONG_PRESS -> longPress(action.x.toFloat(), action.y.toFloat(), action.durationMs)
            ActionType.SWIPE -> swipe(
                action.x.toFloat(), action.y.toFloat(),
                action.endX.toFloat(), action.endY.toFloat(),
                action.durationMs
            )
            ActionType.WAIT -> {}
        }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
        Log.d(TAG, "tap at $x, $y")
    }

    private fun longPress(x: Float, y: Float, durationMs: Int) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.toLong()))
            .build()
        dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
        Log.d(TAG, "longPress at $x, $y for $durationMs")
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Int) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.toLong()))
            .build()
        dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
        Log.d(TAG, "swipe $x1,$y1 -> $x2,$y2")
    }

    companion object {
        private const val TAG = "GameAccessibilityService"
        var instance: GameAccessibilityService? = null
            private set
    }
}
