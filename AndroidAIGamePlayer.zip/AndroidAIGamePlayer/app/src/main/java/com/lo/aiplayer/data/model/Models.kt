package com.lo.aiplayer.data.model

import android.graphics.Bitmap

enum class ActionType {
    TAP, LONG_PRESS, SWIPE, WAIT
}

data class GameAction(
    val type: ActionType,
    val x: Int = 0,
    val y: Int = 0,
    val endX: Int = 0,
    val endY: Int = 0,
    val durationMs: Int = 100,
    val reason: String = ""
)

data class GameProfile(
    val name: String,
    val objective: String,
    val controls: String,
    val hints: String = "",
    val intervalMs: Long = 2000L,
    val captureScale: Float = 0.5f
)

data class FramePayload(
    val bitmap: Bitmap,
    val width: Int,
    val height: Int
)
