package com.lo.aiplayer.data.remote

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.lo.aiplayer.data.model.GameAction
import com.lo.aiplayer.data.model.GameProfile
import com.lo.aiplayer.data.model.ActionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeminiRepository @Inject constructor(
    private val apiService: GeminiApiService
) {
    private val gson = Gson()

    suspend fun decideAction(
        apiKey: String,
        model: String,
        profile: GameProfile,
        screenshot: Bitmap,
        screenWidth: Int,
        screenHeight: Int,
        recentHistory: List<GameAction> = emptyList()
    ): Result<GameAction> = withContext(Dispatchers.IO) {
        try {
            val base64Image = bitmapToBase64(screenshot, profile.captureScale)
            val promptText = buildPrompt(profile, screenWidth, screenHeight, recentHistory)

            val request = GeminiRequest(
                contents = listOf(
                    ContentPart(
                        parts = listOf(
                            Part(text = promptText),
                            Part(
                                inlineData = InlineData(
                                    mimeType = "image/jpeg",
                                    data = base64Image
                                )
                            )
                        )
                    )
                ),
                generationConfig = GenerationConfig(
                    responseMimeType = "application/json",
                    temperature = 0.35f,
                    maxOutputTokens = 512
                )
            )

            val response = apiService.generateContent(model, apiKey, request)
            response.error?.let {
                return@withContext Result.failure(Exception("Gemini error ${it.code}: ${it.message}"))
            }

            val jsonText = response.candidates?.firstOrNull()
                ?.content?.parts?.firstOrNull()?.text
                ?: return@withContext Result.failure(Exception("Empty response from Gemini"))

            Log.d("GeminiRepository", "Raw: $jsonText")
            val action = parseAction(jsonText)
            Result.success(action)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildPrompt(
        profile: GameProfile,
        width: Int,
        height: Int,
        recentHistory: List<GameAction>
    ): String {
        val historyText = if (recentHistory.isEmpty()) {
            "No previous actions yet."
        } else {
            recentHistory.joinToString("\n") {
                "- ${it.type} at (${it.x},${it.y}) reason: ${it.reason}"
            }
        }

        return """
            You are Gemini 3.5 Flash, a professional Android game-playing AI. Analyze the screenshot and pick the best next action.

            Game: ${profile.name}
            Objective: ${profile.objective}
            Controls: ${profile.controls}
            Hints: ${profile.hints}

            Screen size: ${width}x${height} pixels.
            All coordinates you return MUST be inside this rectangle.

            Recent actions (avoid repeating failed moves):
            $historyText

            Return ONLY valid JSON matching this schema:
            {
              "type": "TAP" | "LONG_PRESS" | "SWIPE" | "WAIT",
              "x": integer,
              "y": integer,
              "endX": integer (0 if not SWIPE),
              "endY": integer (0 if not SWIPE),
              "durationMs": integer (80-120 for TAP, 300-800 for LONG_PRESS, 150-400 for SWIPE),
              "reason": "one-line reasoning"
            }

            Rules:
            - WAIT if the screen is loading, animating, unclear, or no safe move exists.
            - SWIPE only when a drag gesture is needed.
            - TAP for buttons, targets, and quick interactions.
            - LONG_PRESS for charged actions or context menus.
            - Prefer progress toward the objective over random moves.
        """.trimIndent()
    }

    private fun parseAction(json: String): GameAction {
        val cleaned = json.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        return try {
            gson.fromJson(cleaned, GameAction::class.java)
        } catch (e: JsonSyntaxException) {
            throw Exception("Failed to parse action JSON: ${e.message}")
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap, scale: Float): String {
        val targetWidth = (bitmap.width * scale).toInt().coerceAtLeast(320)
        val targetHeight = (bitmap.height * scale).toInt().coerceAtLeast(568)
        val scaled = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
        val stream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 72, stream)
        val bytes = stream.toByteArray()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
}
