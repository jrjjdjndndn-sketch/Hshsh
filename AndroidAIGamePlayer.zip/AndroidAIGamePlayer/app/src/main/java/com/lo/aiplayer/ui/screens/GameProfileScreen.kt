package com.lo.aiplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.lo.aiplayer.data.model.GameProfile
import com.lo.aiplayer.ui.theme.Cream
import com.lo.aiplayer.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameProfileScreen(
    viewModel: GameViewModel = hiltViewModel(),
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val profiles = uiState.settings.profiles
    var editingIndex by remember { mutableIntStateOf(-1) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Game Profiles", style = MaterialTheme.typography.headlineMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.addProfile(
                            GameProfile(
                                name = "New Game",
                                objective = "",
                                controls = ""
                            )
                        )
                        editingIndex = profiles.size
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add profile", tint = Cream)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Cream
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            profiles.forEachIndexed { index, profile ->
                val isSelected = index == uiState.settings.selectedProfileIndex
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected)
                            MaterialTheme.colorScheme.primaryContainer
                        else
                            MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectProfile(index) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.selectProfile(index) }
                        )
                        Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                            Text(
                                text = profile.name.ifBlank { "Unnamed Profile" },
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                text = profile.objective,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2
                            )
                        }
                        IconButton(onClick = { editingIndex = index }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                        IconButton(onClick = { viewModel.deleteProfile(index) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }

            if (editingIndex in profiles.indices) {
                Spacer(Modifier.height(16.dp))
                ProfileEditor(
                    profile = profiles[editingIndex],
                    onSave = { updated ->
                        viewModel.updateProfile(editingIndex, updated)
                        editingIndex = -1
                    },
                    onCancel = { editingIndex = -1 }
                )
            }
        }
    }
}

@Composable
private fun ProfileEditor(
    profile: GameProfile,
    onSave: (GameProfile) -> Unit,
    onCancel: () -> Unit
) {
    var name by remember { mutableStateOf(profile.name) }
    var objective by remember { mutableStateOf(profile.objective) }
    var controls by remember { mutableStateOf(profile.controls) }
    var hints by remember { mutableStateOf(profile.hints) }
    var interval by remember { mutableStateOf(profile.intervalMs.toString()) }
    var scale by remember { mutableStateOf(profile.captureScale.toString()) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Edit Profile", style = MaterialTheme.typography.headlineSmall)

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Game Name") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = objective,
            onValueChange = { objective = it },
            label = { Text("Objective") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )

        OutlinedTextField(
            value = controls,
            onValueChange = { controls = it },
            label = { Text("Controls") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        OutlinedTextField(
            value = hints,
            onValueChange = { hints = it },
            label = { Text("Hints / Strategy") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        OutlinedTextField(
            value = interval,
            onValueChange = { interval = it },
            label = { Text("Interval (ms)") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = scale,
            onValueChange = { scale = it },
            label = { Text("Capture Scale (0.3 - 1.0)") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    onSave(
                        GameProfile(
                            name = name.trim(),
                            objective = objective.trim(),
                            controls = controls.trim(),
                            hints = hints.trim(),
                            intervalMs = interval.toLongOrNull() ?: 2000L,
                            captureScale = scale.toFloatOrNull()?.coerceIn(0.1f, 1.0f) ?: 0.5f
                        )
                    )
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Save")
            }
            Button(onClick = onCancel, modifier = Modifier.weight(1f)) {
                Text("Cancel")
            }
        }
    }
}
