package com.lo.aiplayer.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.lo.aiplayer.data.model.GameProfile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val gson = Gson()

    private object Keys {
        val API_KEY = stringPreferencesKey("api_key")
        val MODEL = stringPreferencesKey("model")
        val PROFILES_JSON = stringPreferencesKey("profiles_json")
        val SELECTED_PROFILE_INDEX = intPreferencesKey("selected_profile_index")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences())
            else throw exception
        }
        .map { prefs ->
            val profiles = parseProfiles(prefs[Keys.PROFILES_JSON])
            val selected = prefs[Keys.SELECTED_PROFILE_INDEX] ?: 0
            UserSettings(
                apiKey = prefs[Keys.API_KEY] ?: "",
                model = prefs[Keys.MODEL] ?: MODELS.first(),
                profiles = profiles,
                selectedProfileIndex = selected.coerceIn(0, profiles.size.coerceAtLeast(1) - 1)
            )
        }

    suspend fun saveApiKey(key: String) {
        context.dataStore.edit { it[Keys.API_KEY] = key }
    }

    suspend fun saveModel(model: String) {
        context.dataStore.edit { it[Keys.MODEL] = model }
    }

    suspend fun addProfile(profile: GameProfile) {
        context.dataStore.edit { prefs ->
            val list = parseProfiles(prefs[Keys.PROFILES_JSON]).toMutableList()
            list.add(profile)
            prefs[Keys.PROFILES_JSON] = gson.toJson(list)
            prefs[Keys.SELECTED_PROFILE_INDEX] = list.size - 1
        }
    }

    suspend fun updateProfile(index: Int, profile: GameProfile) {
        context.dataStore.edit { prefs ->
            val list = parseProfiles(prefs[Keys.PROFILES_JSON]).toMutableList()
            if (index in list.indices) {
                list[index] = profile
                prefs[Keys.PROFILES_JSON] = gson.toJson(list)
            }
        }
    }

    suspend fun deleteProfile(index: Int) {
        context.dataStore.edit { prefs ->
            val list = parseProfiles(prefs[Keys.PROFILES_JSON]).toMutableList()
            if (index in list.indices) {
                list.removeAt(index)
                prefs[Keys.PROFILES_JSON] = gson.toJson(list)
                prefs[Keys.SELECTED_PROFILE_INDEX] = 0
            }
        }
    }

    suspend fun selectProfile(index: Int) {
        context.dataStore.edit { it[Keys.SELECTED_PROFILE_INDEX] = index }
    }

    private fun parseProfiles(json: String?): List<GameProfile> {
        if (json.isNullOrBlank()) return listOf(defaultProfile())
        return try {
            val type = object : TypeToken<List<GameProfile>>() {}.type
            gson.fromJson<List<GameProfile>>(json, type).takeIf { it.isNotEmpty() } ?: listOf(defaultProfile())
        } catch (e: Exception) {
            listOf(defaultProfile())
        }
    }

    private fun defaultProfile(): GameProfile = GameProfile(
        name = "Gemini 3.5 Flash Gamer",
        objective = "Play the game shown on screen. Maximize score / progress / survival based on the objective.",
        controls = "TAP to interact. SWIPE to move or aim. LONG_PRESS for charged actions. WAIT when the game is loading or animating.",
        hints = "Use only the controls described. Prefer safe moves over risky ones. If the screen is unclear, choose WAIT and observe.",
        intervalMs = 2000L,
        captureScale = 0.5f
    )

    companion object {
        val MODELS = listOf(
            "gemini-3.5-flash",
            "gemini-3.5-flash-preview",
            "gemini-3.1-flash",
            "gemini-2.5-flash"
        )
    }
}

data class UserSettings(
    val apiKey: String,
    val model: String,
    val profiles: List<GameProfile>,
    val selectedProfileIndex: Int
) {
    val selectedProfile: GameProfile
        get() = profiles.getOrElse(selectedProfileIndex) { profiles.firstOrNull() ?: SettingsDataStore.MODELS.run { GameProfile("", "", "") } }
}
