package com.lo.aiplayer.ui.screens

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.lo.aiplayer.service.GameAccessibilityService
import com.lo.aiplayer.service.ScreenCaptureService
import com.lo.aiplayer.ui.theme.Cream
import com.lo.aiplayer.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GameViewModel = hiltViewModel(),
    onSettings: () -> Unit,
    onProfile: () -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var serviceStarted by remember { mutableStateOf(false) }
    var captureService by remember { mutableStateOf<ScreenCaptureService?>(null) }
    val profile = uiState.settings.selectedProfile

    val projectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, intent)
            serviceStarted = true
        }
    }

    DisposableEffect(serviceStarted) {
        var bound = false
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                val binder = service as ScreenCaptureService.LocalBinder
                captureService = binder.getService()
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                captureService = null
            }
        }

        if (serviceStarted) {
            val bindIntent = Intent(context, ScreenCaptureService::class.java)
            context.bindService(bindIntent, connection, Context.BIND_AUTO_CREATE)
            bound = true
        }

        onDispose {
            if (bound) {
                context.unbindService(connection)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Game Player", style = MaterialTheme.typography.headlineMedium) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Cream
                ),
                actions = {
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Cream)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Profile: ${profile.name}", style = MaterialTheme.typography.bodyLarge)
                    Text("Model: ${uiState.settings.model}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = if (uiState.isRunning) "Status: Running" else "Status: Idle",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (uiState.isRunning) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Button(
                onClick = {
                    val intent = viewModel.requestProjectionIntent()
                    projectionLauncher.launch(intent)
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !serviceStarted
            ) {
                Text("1. Allow Screen Capture")
            }

            Button(
                onClick = { viewModel.openAccessibilitySettings() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("2. Enable AI Accessibility Service")
            }

            Button(
                onClick = {
                    if (uiState.isRunning) {
                        viewModel.stopAiLoop()
                    } else {
                        captureService?.let { service ->
                            viewModel.startAiLoop { service.captureFrame() }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = serviceStarted && GameAccessibilityService.instance != null
            ) {
                Text(if (uiState.isRunning) "Stop AI" else "3. Start Playing")
            }

            Button(onClick = onProfile, modifier = Modifier.fillMaxWidth()) {
                Text("Edit Game Profiles")
            }

            Spacer(Modifier.height(12.dp))

            uiState.lastAction?.let { action ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Last AI Move", style = MaterialTheme.typography.labelLarge)
                        Text("${action.type} (${action.x}, ${action.y})")
                        Text("Reason: ${action.reason}", fontStyle = FontStyle.Italic)
                    }
                }
            }

            uiState.lastError?.let { error ->
                Text(
                    text = "Error: $error",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = "How it works: Gemini 3.5 Flash sees your screen, reasons, and returns the next move. The app executes it through the accessibility service. Keep the game visible.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}
