package com.lo.aiplayer.ui.theme

import androidx.compose.ui.graphics.Color

val CoffeeDark = Color(0xFF3E2723)
val Coffee = Color(0xFF5D4037)
val CoffeeLight = Color(0xFF8D6E63)
val Cream = Color(0xFFFAF7F2)
val Paper = Color(0xFFF5F0E8)
val Ink = Color(0xFF2C2420)
val Muted = Color(0xFFA1887F)
val Accent = Color(0xFFD84315)
