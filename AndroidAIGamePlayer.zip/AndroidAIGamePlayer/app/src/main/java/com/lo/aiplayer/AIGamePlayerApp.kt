package com.lo.aiplayer

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AIGamePlayerApp : Application()
