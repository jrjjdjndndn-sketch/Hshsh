# ProGuard rules for AI Game Player
